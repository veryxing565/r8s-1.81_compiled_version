int			bSLrecurse(NODETYPE *node),
			bSLrecurse2(NODETYPE *node);

StrListPtr root3taxa(StrListPtr list, NODETYPE *root);
