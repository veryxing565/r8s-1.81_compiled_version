void moment(double data[], int n, double *ave, double *adev, double *sdev,
	double *var, double *skew, double *curt);
